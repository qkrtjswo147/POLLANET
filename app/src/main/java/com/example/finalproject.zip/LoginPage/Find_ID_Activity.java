package com.example.finalproject.LoginPage;

import static com.example.finalproject.LoginPage.RemoteService.BASE_URL;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.finalproject.R;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Find_ID_Activity extends AppCompatActivity {

    Toast t;
    Retrofit retrofit;
    RemoteService service;
    Button idprev,idfindbtn;
    EditText username,userTel;
    AlertDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_id);

        username = findViewById(R.id.username);
        userTel = findViewById(R.id.userTel);

        Gson gson = new GsonBuilder()
                .setLenient()
                .create();
        retrofit = new Retrofit.Builder().baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
        service = retrofit.create(RemoteService.class);

        //로그인 버튼을 누른경우 로그인페이지로 이동
        idprev = findViewById(R.id.idprev);
        idprev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Find_ID_Activity.this, LoginActivity.class));
            }
        });

        //아이디찾기
        idfindbtn = findViewById(R.id.idfindbtn);
        idfindbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String name = username.getText().toString().trim();
                String tel = userTel.getText().toString().trim();

                System.out.println("name///// = " + name);
                System.out.println("tel ////= " + tel);
                Call<String> call = service.searchId(name,tel);

                call.enqueue(new Callback<String>() {
                    @Override
                    public void onResponse(Call<String> call, Response<String> response) {
                        System.out.println("response = " + response.body());
                        for (int i = 0; i<30; i++){
                            t=Toast.makeText(getApplicationContext(),"아이디는 "+response.body()+" 입니다.",Toast.LENGTH_LONG);
                            t.setGravity(Gravity.CENTER,0,+250);
                            t.show();
                        }
                    }
                    @Override
                    public void onFailure(Call<String> call, Throwable t) {
                        System.out.println("t = " + t);
                    }
                });

            }
        });

    }
}
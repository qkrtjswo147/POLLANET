package com.example.finalproject.LoginPage;

import com.example.finalproject.BoardVO;
import com.example.finalproject.MissionVO;
import com.example.finalproject.RankingListVO;
import com.example.finalproject.UserPointVO;


import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface RemoteService {
    public static final String BASE_URL = "http://192.168.0.108:8088";

    //스프링 백엔드호출하여 로그인
    @POST("/api/user/userLogin")
    Call<Integer> login(@Body UserInfoVO userInfoVO);

    //회원가입
    @POST("/api/user/userRegister")
    Call<Void> Register(@Body UserStatusVO userStatusVO);

    //Id중복체크크
    @GET("/api/user/userDuplicationId/{str}")
    Call<Integer> duplicationID(@Path("str") String Id);

    //닉네임 중복체크
    @GET("/api/user/userDuplicationNickname/{str}")
    Call<Integer> duplicationNick(@Path("str") String NickName);

    //Id찾기
    @GET("/api/user/userSearchId")
    Call<String> searchId(@Query("name") String name, @Query("tel") String tel);

    //비밀번호 찾기 재설정
    @POST("/api/user/updatepassword")
    Call<Void> updatePassword(@Body UserInfoVO userInfovo);

    //유저검색(userinfo)
    @GET("/api/user/userRead/{user_Id}")
    Call<UserInfoVO> userInfo(@Path("user_Id") String user_Id);

    //유저검색(userStatus)
    @GET("/api/user/userReadSt/{user_id}")
    Call<UserStatusVO> userStatus(@Path("user_id") String user_id);

    //유저 포인트 검색
    @GET("/api/point/read/{user_point_id}")
    Call<UserPointVO> userPoint(@Path("user_point_id") String user_point_id);

    //유저 랭킹
    @GET("/api/point/rank/{user_point_id}")
    Call<Integer> myRank(@Path("user_point_id") String user_point_id);

    //미션6개
    @GET("/api/mission/list?m_keyword=&m_start=4&m_number=6")
    Call<List<MissionVO>> missionList();

    //회원수정
    @POST("/api/user/userupdate")
    Call<Void> userupdate(@Body UserStatusVO userStatusVO);

    //회원탈퇴
    @POST("/api/user/userdelupdate")
    Call<Void> userdel(@Body UserStatusVO userStatusVO);

    //회원랭킹
    @GET("/api/point/rankList")
    Call<List<RankingListVO>> rankList();

    //일일미션
    @GET("/api/mission/categorylist?m_category=&m_sort=d&m_start=0&m_number=8")
    Call<List<MissionVO>> Dcategorylist();

    //주간미션
    @GET("/api/mission/categorylist?m_category=&m_sort=w&m_start=0&m_number=8")
    Call<List<MissionVO>> Wcategorylist();

    //게시판 리스트
    @GET("/api/board/list?page=1&num=10")
    Call<List<BoardVO>> boardList();








}
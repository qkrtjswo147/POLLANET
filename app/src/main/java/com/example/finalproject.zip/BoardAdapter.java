package com.example.finalproject;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.finalproject.LoginPage.RemoteService;

import java.util.List;

import retrofit2.Retrofit;


public class BoardAdapter extends RecyclerView.Adapter<BoardAdapter.ViewHolder> {
    Context context;
    List<BoardVO> array;

    public BoardAdapter(Context context, List<BoardVO> array){
        this.context= context;
        this.array=array;
    }


    @NonNull
    @Override
    public BoardAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.item_board_list, parent, false);
        ViewHolder holder=new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull BoardAdapter.ViewHolder holder, int position) {
        final BoardVO vo=array.get(position);
        holder.title.setText(vo.getB_title());
        holder.userid.setText(vo.getB_user_id());
        holder.category.setText(vo.getB_category());
        holder.recommend_total.setText(String.valueOf(vo.getB_recommend()));
        holder.commend_total.setText(String.valueOf(vo.getB_comment_count()));
        holder.image.setImageBitmap(BitmapFactory.decodeFile(vo.getB_image()));
        holder.date.setText(vo.getB_register_Date());
    }

    @Override
    public int getItemCount() {
        //System.out.println("array.size()//board_list_사이즈.......................... = " + array.size());
        return array.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        ImageView image;
        TextView category, title, userid, recommend_total, commend_total, date;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            image=itemView.findViewById(R.id.board_list_item_image);
            category=itemView.findViewById(R.id.board_list_item_category);
            title=itemView.findViewById(R.id.board_list_item_title);
            userid=itemView.findViewById(R.id.board_list_item_userid);
            recommend_total=itemView.findViewById(R.id.board_list_item_recommend_total);
            commend_total=itemView.findViewById(R.id.board_list_item_commend_total);
            date=itemView.findViewById(R.id.board_list_item_date);
        }
    }
}

package com.example.finalproject;

import static com.example.finalproject.LoginPage.RemoteService.BASE_URL;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.finalproject.LoginPage.RemoteService;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Pati_Mission_Activity extends AppCompatActivity {

    Retrofit retrofit;
    RemoteService service;
    Button btn_pati_mission;
    TextView pati_mission_title,user_pati_mission_title,user_pati_mission_content;
    ImageView pati_mission_image;
    Intent intent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pati_mission);

        retrofit = new Retrofit.Builder().baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        service = retrofit.create(RemoteService.class);


        btn_pati_mission = findViewById(R.id.btn_user_pati_mission);
        btn_pati_mission.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intent =new Intent(Pati_Mission_Activity.this,MainActivity.class);
                startActivity(intent);

            }
        });


    }
}
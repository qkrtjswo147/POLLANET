package com.example.finalproject;

import static com.example.finalproject.LoginPage.RemoteService.BASE_URL;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.finalproject.LoginPage.RemoteService;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class HomeFragment extends Fragment {
    Fragment todayMissionFragment;
    Fragment recommendFragment;
    BottomNavigationView bottomNavigationView;
    UserPointVO userPointVO;
    Retrofit retrofit;
    RemoteService service;
    String user_id;
    String user_point;
    String user;
    String userID;




    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        ViewGroup v=(ViewGroup) inflater.inflate(R.layout.fragment_home, container, false);
        retrofit = new Retrofit.Builder().baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        service = retrofit.create(RemoteService.class);

        TextView recommend_board=(TextView) v.findViewById(R.id.recommend_board_text_1);
        TextView today_mission=(TextView) v.findViewById(R.id.today_mission_text);
        TextView mission_perfection = (TextView) v.findViewById(R.id.mission_perfection);
        userID = getArguments().getString("userID");

        //System.out.println("user_id =/////프래그먼트ㅡㅡㅡ " + user_id);

        Call<UserPointVO> userPointVOCall = service.userPoint(userID);
        userPointVOCall.enqueue(new Callback<UserPointVO>() {
            @Override
            public void onResponse(Call<UserPointVO> call, Response<UserPointVO> response) {
                System.out.println("response = " + response.body());
                userPointVO = response.body();
                user_point = String.valueOf(userPointVO.getUser_point());
                mission_perfection.setText(user_point);
            }

            @Override
            public void onFailure(Call<UserPointVO> call, Throwable t) {
                System.out.println("t =////////// " + t);
            }
        });

        recommend_board.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment boardFragment=new BoardFragment();
                FragmentTransaction fragmentTransaction=getActivity().getSupportFragmentManager().beginTransaction();
                fragmentTransaction.replace(R.id.container, boardFragment).commit();
            }
        });
        today_mission.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment missionFragment=new com.example.finalproject.MissionFragment();
                FragmentTransaction fragmentTransaction=getActivity().getSupportFragmentManager().beginTransaction();
                fragmentTransaction.replace(R.id.container, missionFragment).commit();
            }
        });
        return v;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recommendFragment=new com.example.finalproject.Recommend_Board_List_Fragment();
        todayMissionFragment=new com.example.finalproject.Today_Mission_Fragment();

        FragmentTransaction childTransaction = getChildFragmentManager().beginTransaction();

        childTransaction.replace(R.id.today_mission_container, todayMissionFragment);

        childTransaction.replace(R.id.recommend_board_container, recommendFragment);

        childTransaction.commit();
    }


}
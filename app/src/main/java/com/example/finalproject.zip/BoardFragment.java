package com.example.finalproject;

import static com.example.finalproject.LoginPage.RemoteService.BASE_URL;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.finalproject.LoginPage.RemoteService;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class BoardFragment extends Fragment {
    RecyclerView list;
    RemoteService remoteService;
    Retrofit retrofit;
    BoardAdapter adapter;
    List<BoardVO> array=new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        ViewGroup v=(ViewGroup) inflater.inflate(R.layout.fragment_board, container, false);



        //레트로핏 정의
        retrofit=new Retrofit.Builder().baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        remoteService=retrofit.create(RemoteService.class);

        Call<List<BoardVO>> call=remoteService.boardList();
        call.enqueue(new Callback<List<BoardVO>>() {
            @Override
            public void onResponse(Call<List<BoardVO>> call, Response<List<BoardVO>> response) {
                System.out.println("response.body()보드쪽............. = " + response.body());
                array= response.body();
                System.out.println("list.size = " +array.size());

                list=v.findViewById(R.id.board_list);
                adapter= new BoardAdapter(getContext(), array);
                list.setAdapter(adapter);
            }
            @Override
            public void onFailure(Call<List<BoardVO>> call, Throwable t) {
                System.out.println("toString() = call...오류 " + t);
            }
        });

        return v;
    }
}
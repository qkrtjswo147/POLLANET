package com.example.finalproject;

import static com.example.finalproject.LoginPage.RemoteService.BASE_URL;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.finalproject.LoginPage.RemoteService;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Select_Mission_Activity extends AppCompatActivity {

    Retrofit retrofit;
    RemoteService service;
    TextView selectTitle, selectCode;
    Intent intent;
    String missionCode;
    Button btn_mission_join;
    int code;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_mission);


        intent = getIntent();
        missionCode = intent.getStringExtra("code");
        System.out.println("missionCode ///////////////미션코드= " + missionCode);

        code = Integer.parseInt(missionCode);
        System.out.println("code = //////숫잠션코드" + code);

        retrofit = new Retrofit.Builder().baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        service = retrofit.create(RemoteService.class);

        selectTitle = findViewById(R.id.selectTitle);

        Call<List<MissionVO>> callmission = service.missionList();
        callmission.enqueue(new Callback<List<MissionVO>>() {
            @Override
            public void onResponse(Call<List<MissionVO>> call, Response<List<MissionVO>> response) {


            }

            @Override
            public void onFailure(Call<List<MissionVO>> call, Throwable t) {

            }
        });


        btn_mission_join = findViewById(R.id.btn_mission_join);
        btn_mission_join.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Select_Mission_Activity.this,Pati_Mission_Activity.class);
                startActivity(intent);
                finish();

            }
        });









    }
}
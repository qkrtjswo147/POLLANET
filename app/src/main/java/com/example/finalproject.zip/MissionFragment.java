package com.example.finalproject;

import static com.example.finalproject.LoginPage.RemoteService.BASE_URL;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.finalproject.LoginPage.RemoteService;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class MissionFragment extends Fragment {

    Fragment weekly_mission_list_fragment;
    Fragment daily_mission_list_fragment;
    Context ct;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        ViewGroup v=(ViewGroup) inflater.inflate(R.layout.fragment_mission, container, false);
        ct = container.getContext();
        ImageView imageView=(ImageView) v.findViewById(R.id.mission_view);
        Glide.with(ct).load(R.drawable.sample_1).into(imageView);

        return v;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        daily_mission_list_fragment=new Daily_Mission_List_Fragment();
        weekly_mission_list_fragment=new Weekly_Mission_List_Fragment();


        FragmentTransaction childTransaction = getChildFragmentManager().beginTransaction();

        childTransaction.replace(R.id.daily_mission_frame, daily_mission_list_fragment);
        childTransaction.replace(R.id.weekly_mission_frame, weekly_mission_list_fragment);
        childTransaction.commit();
    }
}
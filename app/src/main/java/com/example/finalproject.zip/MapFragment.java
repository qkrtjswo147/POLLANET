package com.example.finalproject;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;

import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import net.daum.android.map.MapViewEventListener;
import net.daum.mf.map.api.MapPOIItem;
import net.daum.mf.map.api.MapPoint;
import net.daum.mf.map.api.MapView;

public class MapFragment extends Fragment {
    Context ct;
    MapView mapView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        ViewGroup v = (ViewGroup) inflater.inflate(R.layout.fragment_map, container, false);
        ct = container.getContext();
        FloatingActionButton button= (FloatingActionButton) v.findViewById(R.id.tracking_button);

        mapView= new MapView(getActivity());

        ViewGroup mapViewContainer = (ViewGroup) v.findViewById(R.id.map_view);
        mapViewContainer.addView(mapView);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startTracking();
            }
        });

        // 줌 레벨 변경
        mapView.setZoomLevel(7, true);

        return v;
    }
    //gps확인


    @SuppressWarnings ({"MissingPermission"})
    public void startTracking(){
        // 현재위치 트래킹
        mapView.setCurrentLocationTrackingMode(MapView.CurrentLocationTrackingMode.TrackingModeOnWithoutHeading);
        LocationManager locationManager= (LocationManager) getContext().getSystemService(Context.LOCATION_SERVICE);
        Location userLocation = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
        double uLatitude = userLocation.getLatitude();
        double uLongitude = userLocation.getLongitude();
        MapPoint userNowLocation=MapPoint.mapPointWithGeoCoord(uLatitude, uLongitude);

        //위치찍기
        MapPoint MARKER_POINT = userNowLocation;
        MapPOIItem marker = new MapPOIItem();
        marker.setItemName("현재위치");
        marker.setMapPoint(MARKER_POINT);
        marker.setMarkerType(MapPOIItem.MarkerType.BluePin); // 기본으로 제공하는 BluePin 마커 모양.
        marker.setSelectedMarkerType(MapPOIItem.MarkerType.RedPin); // 마커를 클릭했을때, 기본으로 제공하는 RedPin 마커 모양.
        mapView.addPOIItem(marker);
    }

    // 위치추적 중지
    public void stopTracking(){
        mapView.setCurrentLocationTrackingMode(MapView.CurrentLocationTrackingMode.TrackingModeOff);
    }

}
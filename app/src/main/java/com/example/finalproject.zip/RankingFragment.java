package com.example.finalproject;

import static com.example.finalproject.LoginPage.RemoteService.BASE_URL;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.finalproject.LoginPage.RemoteService;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class RankingFragment extends Fragment {

    String userId;  //자동로그인을 체크안하고 로그인한경우의 id값
    String user_id;//자동로그인을 체크하고 로그인한경우의 id값
    Retrofit retrofit;
    RemoteService service;
    Fragment Ranking_List_Fragment;
    RecyclerView Rlist;
    TextView my_Rank, topNickname, secondNickname, thirdNickname, topPoint, secondPoint, thirdPoint;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        ViewGroup v = (ViewGroup) inflater.inflate(R.layout.fragment_ranking, container, false);

        retrofit = new Retrofit.Builder().baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        service = retrofit.create(RemoteService.class);
        user_id = getArguments().getString("userID");
        my_Rank = (TextView) v.findViewById(R.id.my_Ranking_score);
        topNickname = (TextView) v.findViewById(R.id.ranking_top_nickname);
        secondNickname = (TextView) v.findViewById(R.id.ranking_second_nickname);
        thirdNickname = (TextView) v.findViewById(R.id.ranking_third_nickname);
        topPoint = (TextView) v.findViewById(R.id.ranking_top_point);
        secondPoint = (TextView) v.findViewById(R.id.ranking_second_point);
        thirdPoint = (TextView) v.findViewById(R.id.ranking_third_point);

        Call<Integer> callmyRank = service.myRank(user_id);
        callmyRank.enqueue(new Callback<Integer>() {
            @Override
            public void onResponse(Call<Integer> call, Response<Integer> response) {
                String myRank = String.valueOf(response.body());
                my_Rank.setText(myRank);
            }
            @Override
            public void onFailure(Call<Integer> call, Throwable t) {
                System.out.println("-----------------!!!!!!!" + t.toString());
            }
        });

        Call<List<RankingListVO>> calltopRanking = service.rankList();
        calltopRanking.enqueue(new Callback<List<RankingListVO>>() {
            @Override
            public void onResponse(Call<List<RankingListVO>> call, Response<List<RankingListVO>> response) {
                System.out.println(" =////////////////////// " + response.code());
                System.out.println("response ///////////= " + response.body());
                List<RankingListVO> result = response.body();
                RankingListVO rankingVO1 = result.get(0);
                RankingListVO rankingVO2 = result.get(1);
                RankingListVO rankingVO3 = result.get(2);

                topNickname.setText(rankingVO1.getNickName());
                secondNickname.setText(rankingVO2.getNickName());
                thirdNickname.setText(rankingVO3.getNickName());
                topPoint.setText(rankingVO1.getUser_point());
                secondPoint.setText(rankingVO2.getUser_point());
                thirdPoint.setText(rankingVO3.getUser_point());


            }

            @Override
            public void onFailure(Call<List<RankingListVO>> call, Throwable t) {
                System.out.println("t =////////// " + t);
            }
        });
        return v;

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Ranking_List_Fragment = new Ranking_List_Fragment();
        FragmentTransaction childTransaction = getChildFragmentManager().beginTransaction();
        childTransaction.replace(R.id.ranking_list, Ranking_List_Fragment).commit();

    }


}